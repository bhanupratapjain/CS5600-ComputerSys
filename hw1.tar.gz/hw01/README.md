# Running Instruction for HW01

```
- make check
- make res
```