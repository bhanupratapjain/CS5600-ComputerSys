# Running Instruction for HW01

```
- tar -xvf hw1.tar.gz
- cd hw1
- make check
- make res
```